import React from 'react'
import "./blogs.css";

const Blogs = () => {
  return (
    <div>Blogs</div>
  )
}

export default Blogs